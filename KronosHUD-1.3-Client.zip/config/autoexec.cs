//Don't write your own scripts in here, just place execs.
//Keep in mind this file may be replaced in future Tribes Repack updates.
exec("SinConnect.cs");
exec("presto\\install.cs");

// =====================================================================
// Kronos modern GUI / HUD (https://github.com/jcmolnar/Tribes-RPG-1.3-Kronos-HUD)
// LOAD ORDER MATTERS - keep it exactly as below.
// =====================================================================

// Stock Hudbot vhud framework (resolution-scaling HUD base).
exec("scriptgl2.cs");

// vhud HUD: HP/MP/XP, Lv/Gold, cast bar, weapon popup, target frame. Loads first.
exec("Presto\\KronosHUD.cs");

// Chat category filters (ads/cast/loot toggle buttons + persistence).
exec("Presto\\ChatFilter.cs");

// Shared ScriptGL text-input field (keyboard capture). Load before consumers.
// Requires the kronos_textinput plugin (Plugins\kronos_textinput.dll).
exec("Presto\\KronosInput.cs");

// Modern ScriptGL TAB menu + player list + UI-scale slider + drag framework.
exec("Presto\\KronosMenu.cs");

// Modern shop / inventory / bank screen (AFTER KronosMenu).
exec("Presto\\KronosShop.cs");

// Custom ScriptGL chat overlay + composer (AFTER the others).
exec("Presto\\KronosChat.cs");

// Modern NPC dialogue window.
exec("Presto\\KronosNPC.cs");

// ScriptGL quick command menu (Ctrl+V) - self-disables off-Kronos.
exec("Presto\\KronosCM.cs");

// Session stats panel (XP/hr, gold/hr) - client-side, draggable.
exec("Presto\\KronosStats.cs");
